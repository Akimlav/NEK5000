
T = 20  # Temperature Celsius
nutnu = 10  # Eddy viscosity ratio
Tu = 0.5  # Turbulence intensity/leve

#controlDict options
endTime = 20 #calculation end time
writeInterval = 1 # write interval
n_of_proc = 30 # number of processors for decomposeParDict
